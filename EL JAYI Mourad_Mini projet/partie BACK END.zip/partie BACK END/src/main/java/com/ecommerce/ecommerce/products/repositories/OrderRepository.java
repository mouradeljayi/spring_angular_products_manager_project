package com.ecommerce.ecommerce.products.repositories;

import com.ecommerce.ecommerce.products.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
}
